--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.10
-- Dumped by pg_dump version 9.5.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: cube; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS cube WITH SCHEMA public;


--
-- Name: EXTENSION cube; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION cube IS 'data type for multidimensional cubes';


--
-- Name: dict_xsyn; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS dict_xsyn WITH SCHEMA public;


--
-- Name: EXTENSION dict_xsyn; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION dict_xsyn IS 'text search dictionary template for extended synonym processing';


--
-- Name: fuzzystrmatch; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS fuzzystrmatch WITH SCHEMA public;


--
-- Name: EXTENSION fuzzystrmatch; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION fuzzystrmatch IS 'determine similarities and distance between strings';


--
-- Name: hstore; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS hstore WITH SCHEMA public;


--
-- Name: EXTENSION hstore; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION hstore IS 'data type for storing sets of (key, value) pairs';


--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: tablefunc; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS tablefunc WITH SCHEMA public;


--
-- Name: EXTENSION tablefunc; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION tablefunc IS 'functions that manipulate whole tables, including crosstab';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: batch_to_ies; Type: TABLE; Schema: public; Owner: vagrant
--

CREATE TABLE batch_to_ies (
    id uuid DEFAULT uuid_generate_v4() NOT NULL,
    batch_id uuid NOT NULL,
    ie_id uuid NOT NULL,
    lock_version integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    phase character varying(256) NOT NULL,
    step character varying(256) NOT NULL,
    status character varying(256) NOT NULL,
    notes text,
    data text
);


ALTER TABLE batch_to_ies OWNER TO vagrant;

--
-- Name: batch_to_ses; Type: TABLE; Schema: public; Owner: vagrant
--

CREATE TABLE batch_to_ses (
    id uuid DEFAULT uuid_generate_v4() NOT NULL,
    batch_id uuid NOT NULL,
    se_id uuid NOT NULL,
    lock_version integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    phase character varying(256) NOT NULL,
    step character varying(256) NOT NULL,
    status character varying(256) NOT NULL,
    notes text,
    data text
);


ALTER TABLE batch_to_ses OWNER TO vagrant;

--
-- Name: batches; Type: TABLE; Schema: public; Owner: vagrant
--

CREATE TABLE batches (
    id uuid DEFAULT uuid_generate_v4() NOT NULL,
    name character varying(1024) NOT NULL,
    source_file character varying(1024),
    coll_id uuid,
    batch_type character varying(128) NOT NULL,
    batch_number integer DEFAULT 1 NOT NULL,
    notes text,
    lock_version integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE batches OWNER TO vagrant;

--
-- Name: bdis; Type: TABLE; Schema: public; Owner: vagrant
--

CREATE TABLE bdis (
    id uuid DEFAULT uuid_generate_v4() NOT NULL,
    scan_order character varying(255),
    read_order character varying(255),
    binding_orientation character varying(255),
    se_id uuid,
    notes text,
    lock_version integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE bdis OWNER TO vagrant;

--
-- Name: colls; Type: TABLE; Schema: public; Owner: vagrant
--

CREATE TABLE colls (
    id uuid DEFAULT uuid_generate_v4() NOT NULL,
    partner_id uuid NOT NULL,
    code character varying(255) NOT NULL,
    name character varying(255),
    rel_path character varying(4096),
    quota bigint,
    coll_type character varying(255) NOT NULL,
    ready_for_content boolean DEFAULT false,
    lock_version integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE colls OWNER TO vagrant;

--
-- Name: etofids; Type: TABLE; Schema: public; Owner: vagrant
--

CREATE TABLE etofids (
    id uuid DEFAULT uuid_generate_v4() NOT NULL,
    eid uuid NOT NULL,
    etype character varying(255) NOT NULL,
    fid_type character varying(255) NOT NULL,
    fid_value character varying(255) NOT NULL,
    lock_version integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE etofids OWNER TO vagrant;

--
-- Name: etofmds; Type: TABLE; Schema: public; Owner: vagrant
--

CREATE TABLE etofmds (
    id uuid DEFAULT uuid_generate_v4() NOT NULL,
    eid uuid NOT NULL,
    etype character varying(255) NOT NULL,
    fmd_id uuid NOT NULL,
    role character varying(255),
    lock_version integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE etofmds OWNER TO vagrant;

--
-- Name: fmds; Type: TABLE; Schema: public; Owner: vagrant
--

CREATE TABLE fmds (
    id uuid DEFAULT uuid_generate_v4() NOT NULL,
    partner_id uuid NOT NULL,
    coll_id uuid NOT NULL,
    xip_id uuid,
    size bigint NOT NULL,
    pres_level character varying(255),
    pres_commitment character varying(255),
    status character varying(255),
    fmt_valid boolean,
    fmt_acceptable boolean,
    original_name character varying(512) NOT NULL,
    name character varying(512) NOT NULL,
    extension character varying(255),
    file_mtime timestamp without time zone NOT NULL,
    hash_md5 character varying(255),
    hash_sha1 character varying(255),
    hash_sha256 character varying(255),
    hash_sha512 character varying(255),
    fmts text,
    data text,
    lock_version integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE fmds OWNER TO vagrant;

--
-- Name: ie_to_ses; Type: TABLE; Schema: public; Owner: vagrant
--

CREATE TABLE ie_to_ses (
    id uuid DEFAULT uuid_generate_v4() NOT NULL,
    ie_id uuid NOT NULL,
    se_id uuid NOT NULL,
    "order" integer DEFAULT 1 NOT NULL,
    section integer DEFAULT 1 NOT NULL,
    notes text,
    lock_version integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE ie_to_ses OWNER TO vagrant;

--
-- Name: ies; Type: TABLE; Schema: public; Owner: vagrant
--

CREATE TABLE ies (
    id uuid DEFAULT uuid_generate_v4() NOT NULL,
    coll_id uuid NOT NULL,
    sys_num character varying(256) NOT NULL,
    phase character varying(256) DEFAULT 'identified'::character varying NOT NULL,
    step character varying(256) DEFAULT 'none'::character varying NOT NULL,
    status character varying(256) DEFAULT 'pause'::character varying NOT NULL,
    title character varying(4096),
    notes text,
    lock_version integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE ies OWNER TO vagrant;

--
-- Name: partners; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE partners (
    id uuid DEFAULT uuid_generate_v4() NOT NULL,
    code character varying(255) NOT NULL,
    name character varying(1024),
    lock_version integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    rel_path character varying(4096)
);


ALTER TABLE partners OWNER TO postgres;

--
-- Name: providers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE providers (
    id uuid DEFAULT uuid_generate_v4() NOT NULL,
    name character varying(1024) NOT NULL,
    lock_version integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE providers OWNER TO postgres;

--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE schema_migrations (
    version character varying(255) NOT NULL
);


ALTER TABLE schema_migrations OWNER TO postgres;

--
-- Name: ses; Type: TABLE; Schema: public; Owner: vagrant
--

CREATE TABLE ses (
    id uuid DEFAULT uuid_generate_v4() NOT NULL,
    coll_id uuid NOT NULL,
    digi_id character varying(256) NOT NULL,
    do_type character varying(256) NOT NULL,
    phase character varying(256) NOT NULL,
    step character varying(256) NOT NULL,
    status character varying(256) NOT NULL,
    notes text,
    lock_version integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    label character varying(255),
    title character varying(4096)
);


ALTER TABLE ses OWNER TO vagrant;

--
-- Data for Name: batch_to_ies; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY batch_to_ies (id, batch_id, ie_id, lock_version, created_at, updated_at, phase, step, status, notes, data) FROM stdin;
\.


--
-- Data for Name: batch_to_ses; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY batch_to_ses (id, batch_id, se_id, lock_version, created_at, updated_at, phase, step, status, notes, data) FROM stdin;
\.


--
-- Data for Name: batches; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY batches (id, name, source_file, coll_id, batch_type, batch_number, notes, lock_version, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: bdis; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY bdis (id, scan_order, read_order, binding_orientation, se_id, notes, lock_version, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: colls; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY colls (id, partner_id, code, name, rel_path, quota, coll_type, ready_for_content, lock_version, created_at, updated_at) FROM stdin;
b9612d5d-619a-4ceb-b620-d816e4b4340b	e6517775-6277-4e25-9373-ee7738e820b5	test	Test Collection	content/dlts/test	500	origin	t	0	2020-05-30 01:58:38.431824	2020-05-30 01:58:38.431824
\.


--
-- Data for Name: etofids; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY etofids (id, eid, etype, fid_type, fid_value, lock_version, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: etofmds; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY etofmds (id, eid, etype, fmd_id, role, lock_version, created_at, updated_at) FROM stdin;
3ca8ecaf-6fae-48a5-8441-5a96e119ad28	8c258cb2-d700-43be-8773-a61a7b9cd668	se	4a3f8f8c-6dbe-4d7c-bff1-1b973f9f615c	\N	0	2020-05-31 20:37:30.747383	2020-05-31 20:37:30.747383
d9824815-edf1-4ea4-b6f3-8ea05740e7a1	9ea98441-b6b6-46cf-b6c8-91dff385c6c8	ie	f9f38cc5-0728-4f1a-85ec-e4cb6906d304	\N	0	2020-05-31 21:00:11.486657	2020-05-31 21:00:11.486657
3e292c4d-ff00-4cc0-85e0-0028e5a1978e	8c258cb2-d700-43be-8773-a61a7b9cd668	se	ed11a83d-9d88-4ee2-9d8f-bae055d41ed4	\N	0	2020-05-31 21:19:24.42627	2020-05-31 21:19:24.42627
eeb0ba03-d90b-48ee-afa0-44179827f01e	8c258cb2-d700-43be-8773-a61a7b9cd668	se	c9416e9a-5d6d-4cb3-b16f-8d957628759a	\N	0	2020-05-31 21:23:05.918524	2020-05-31 21:23:05.918524
\.


--
-- Data for Name: fmds; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY fmds (id, partner_id, coll_id, xip_id, size, pres_level, pres_commitment, status, fmt_valid, fmt_acceptable, original_name, name, extension, file_mtime, hash_md5, hash_sha1, hash_sha256, hash_sha512, fmts, data, lock_version, created_at, updated_at) FROM stdin;
f9f38cc5-0728-4f1a-85ec-e4cb6906d304	e6517775-6277-4e25-9373-ee7738e820b5	b9612d5d-619a-4ceb-b620-d816e4b4340b	\N	8888	\N	\N	ok	\N	\N	bar.txt	foo.txt	txt	2020-05-30 02:23:33.187013	\N	\N	\N	\N	\N	\N	0	2020-05-30 02:23:33.189808	2020-05-30 02:23:33.189808
ed11a83d-9d88-4ee2-9d8f-bae055d41ed4	e6517775-6277-4e25-9373-ee7738e820b5	b9612d5d-619a-4ceb-b620-d816e4b4340b	\N	9999	\N	\N	ok	\N	\N	bar.txt	bar.pdf	pdf	2020-05-30 02:22:10.935195	\N	\N	\N	\N	\N	\N	0	2020-05-30 02:22:10.938299	2020-05-30 02:22:10.938299
c9416e9a-5d6d-4cb3-b16f-8d957628759a	e6517775-6277-4e25-9373-ee7738e820b5	b9612d5d-619a-4ceb-b620-d816e4b4340b	\N	7777	\N	\N	ok	\N	\N	bar.txt	baz.tif	tif	2020-05-30 02:23:42.724841	\N	\N	\N	\N	\N	\N	0	2020-05-30 02:23:42.727161	2020-05-30 02:23:42.727161
4a3f8f8c-6dbe-4d7c-bff1-1b973f9f615c	e6517775-6277-4e25-9373-ee7738e820b5	b9612d5d-619a-4ceb-b620-d816e4b4340b	\N	1111	\N	\N	ok	\N	\N	bar.txt	foo.pdf	pdf	2020-05-30 02:21:59.710082	\N	\N	\N	\N	\N	{"searchable":true}	2	2020-05-30 02:21:59.712249	2020-06-01 02:40:48.847968
\.


--
-- Data for Name: ie_to_ses; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY ie_to_ses (id, ie_id, se_id, "order", section, notes, lock_version, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ies; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY ies (id, coll_id, sys_num, phase, step, status, title, notes, lock_version, created_at, updated_at) FROM stdin;
9ea98441-b6b6-46cf-b6c8-91dff385c6c8	b9612d5d-619a-4ceb-b620-d816e4b4340b	123456	registration	loading	done	\N	\N	0	2020-05-31 20:57:58.618778	2020-05-31 20:57:58.618778
\.


--
-- Data for Name: partners; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY partners (id, code, name, lock_version, created_at, updated_at, rel_path) FROM stdin;
e6517775-6277-4e25-9373-ee7738e820b5	dlts	nyu dlts	0	2020-05-30 01:56:01.603073	2020-05-30 01:56:01.603073	content/dlts
\.


--
-- Data for Name: providers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY providers (id, name, lock_version, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY schema_migrations (version) FROM stdin;
20131229174225
20131229174456
20131229185210
20131229190449
20140209003342
20140217185630
20140217193210
20140522200358
20140818153515
20141111014915
20150731144753
20150731165222
20161110180003
20161110185056
20161110214154
20161129172630
20180406224231
20190712164528
20190716141514
20190718182720
20190723014017
20190723193815
20200501143107
20200507145713
20200513165918
20200519191510
20200527180853
20200527195414
20200529144906
20200603181816
\.


--
-- Data for Name: ses; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY ses (id, coll_id, digi_id, do_type, phase, step, status, notes, lock_version, created_at, updated_at, label, title) FROM stdin;
8c258cb2-d700-43be-8773-a61a7b9cd668	b9612d5d-619a-4ceb-b620-d816e4b4340b	foo	video	digitization	digitization	active	\N	0	2020-05-30 02:07:17.8462	2020-05-30 02:07:17.8462	\N	\N
\.


--
-- Name: batch_to_ies_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY batch_to_ies
    ADD CONSTRAINT batch_to_ies_pkey PRIMARY KEY (id);


--
-- Name: batch_to_ses_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY batch_to_ses
    ADD CONSTRAINT batch_to_ses_pkey PRIMARY KEY (id);


--
-- Name: batches_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY batches
    ADD CONSTRAINT batches_pkey PRIMARY KEY (id);


--
-- Name: bdis_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY bdis
    ADD CONSTRAINT bdis_pkey PRIMARY KEY (id);


--
-- Name: colls_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY colls
    ADD CONSTRAINT colls_pkey PRIMARY KEY (id);


--
-- Name: etofids_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY etofids
    ADD CONSTRAINT etofids_pkey PRIMARY KEY (id);


--
-- Name: etofmds_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY etofmds
    ADD CONSTRAINT etofmds_pkey PRIMARY KEY (id);


--
-- Name: fmds_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY fmds
    ADD CONSTRAINT fmds_pkey PRIMARY KEY (id);


--
-- Name: ie_to_ses_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY ie_to_ses
    ADD CONSTRAINT ie_to_ses_pkey PRIMARY KEY (id);


--
-- Name: ies_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY ies
    ADD CONSTRAINT ies_pkey PRIMARY KEY (id);


--
-- Name: partners_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY partners
    ADD CONSTRAINT partners_pkey PRIMARY KEY (id);


--
-- Name: providers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY providers
    ADD CONSTRAINT providers_pkey PRIMARY KEY (id);


--
-- Name: ses_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY ses
    ADD CONSTRAINT ses_pkey PRIMARY KEY (id);


--
-- Name: index_batch_to_ies_on_batch_id; Type: INDEX; Schema: public; Owner: vagrant
--

CREATE INDEX index_batch_to_ies_on_batch_id ON batch_to_ies USING btree (batch_id);


--
-- Name: index_batch_to_ies_on_batch_id_and_ie_id; Type: INDEX; Schema: public; Owner: vagrant
--

CREATE UNIQUE INDEX index_batch_to_ies_on_batch_id_and_ie_id ON batch_to_ies USING btree (batch_id, ie_id);


--
-- Name: index_batch_to_ies_on_ie_id; Type: INDEX; Schema: public; Owner: vagrant
--

CREATE INDEX index_batch_to_ies_on_ie_id ON batch_to_ies USING btree (ie_id);


--
-- Name: index_batch_to_ses_on_batch_id; Type: INDEX; Schema: public; Owner: vagrant
--

CREATE INDEX index_batch_to_ses_on_batch_id ON batch_to_ses USING btree (batch_id);


--
-- Name: index_batch_to_ses_on_batch_id_and_se_id; Type: INDEX; Schema: public; Owner: vagrant
--

CREATE UNIQUE INDEX index_batch_to_ses_on_batch_id_and_se_id ON batch_to_ses USING btree (batch_id, se_id);


--
-- Name: index_batch_to_ses_on_se_id; Type: INDEX; Schema: public; Owner: vagrant
--

CREATE INDEX index_batch_to_ses_on_se_id ON batch_to_ses USING btree (se_id);


--
-- Name: index_batches_on_batch_number; Type: INDEX; Schema: public; Owner: vagrant
--

CREATE INDEX index_batches_on_batch_number ON batches USING btree (batch_number);


--
-- Name: index_batches_on_batch_type; Type: INDEX; Schema: public; Owner: vagrant
--

CREATE INDEX index_batches_on_batch_type ON batches USING btree (batch_type);


--
-- Name: index_batches_on_coll_id; Type: INDEX; Schema: public; Owner: vagrant
--

CREATE INDEX index_batches_on_coll_id ON batches USING btree (coll_id);


--
-- Name: index_batches_on_coll_id_and_batch_type_and_batch_number; Type: INDEX; Schema: public; Owner: vagrant
--

CREATE UNIQUE INDEX index_batches_on_coll_id_and_batch_type_and_batch_number ON batches USING btree (coll_id, batch_type, batch_number);


--
-- Name: index_bdis_on_se_id; Type: INDEX; Schema: public; Owner: vagrant
--

CREATE UNIQUE INDEX index_bdis_on_se_id ON bdis USING btree (se_id);


--
-- Name: index_colls_on_code; Type: INDEX; Schema: public; Owner: vagrant
--

CREATE INDEX index_colls_on_code ON colls USING btree (code);


--
-- Name: index_colls_on_partner_id; Type: INDEX; Schema: public; Owner: vagrant
--

CREATE INDEX index_colls_on_partner_id ON colls USING btree (partner_id);


--
-- Name: index_colls_on_partner_id_and_code; Type: INDEX; Schema: public; Owner: vagrant
--

CREATE UNIQUE INDEX index_colls_on_partner_id_and_code ON colls USING btree (partner_id, code);


--
-- Name: index_etofids_on_eid; Type: INDEX; Schema: public; Owner: vagrant
--

CREATE INDEX index_etofids_on_eid ON etofids USING btree (eid);


--
-- Name: index_etofids_on_etype_and_fid_type_and_fid_value; Type: INDEX; Schema: public; Owner: vagrant
--

CREATE UNIQUE INDEX index_etofids_on_etype_and_fid_type_and_fid_value ON etofids USING btree (etype, fid_type, fid_value);


--
-- Name: index_etofids_on_fid_value; Type: INDEX; Schema: public; Owner: vagrant
--

CREATE INDEX index_etofids_on_fid_value ON etofids USING btree (fid_value);


--
-- Name: index_etofmds_on_eid; Type: INDEX; Schema: public; Owner: vagrant
--

CREATE INDEX index_etofmds_on_eid ON etofmds USING btree (eid);


--
-- Name: index_etofmds_on_eid_and_fmd_id_and_role; Type: INDEX; Schema: public; Owner: vagrant
--

CREATE UNIQUE INDEX index_etofmds_on_eid_and_fmd_id_and_role ON etofmds USING btree (eid, fmd_id, role);


--
-- Name: index_etofmds_on_fmd_id; Type: INDEX; Schema: public; Owner: vagrant
--

CREATE INDEX index_etofmds_on_fmd_id ON etofmds USING btree (fmd_id);


--
-- Name: index_etofmds_on_role; Type: INDEX; Schema: public; Owner: vagrant
--

CREATE INDEX index_etofmds_on_role ON etofmds USING btree (role);


--
-- Name: index_fmds_on_coll_id; Type: INDEX; Schema: public; Owner: vagrant
--

CREATE INDEX index_fmds_on_coll_id ON fmds USING btree (coll_id);


--
-- Name: index_fmds_on_extension; Type: INDEX; Schema: public; Owner: vagrant
--

CREATE INDEX index_fmds_on_extension ON fmds USING btree (extension);


--
-- Name: index_fmds_on_hash_md5; Type: INDEX; Schema: public; Owner: vagrant
--

CREATE INDEX index_fmds_on_hash_md5 ON fmds USING btree (hash_md5);


--
-- Name: index_fmds_on_hash_sha1; Type: INDEX; Schema: public; Owner: vagrant
--

CREATE INDEX index_fmds_on_hash_sha1 ON fmds USING btree (hash_sha1);


--
-- Name: index_fmds_on_hash_sha256; Type: INDEX; Schema: public; Owner: vagrant
--

CREATE INDEX index_fmds_on_hash_sha256 ON fmds USING btree (hash_sha256);


--
-- Name: index_fmds_on_hash_sha512; Type: INDEX; Schema: public; Owner: vagrant
--

CREATE INDEX index_fmds_on_hash_sha512 ON fmds USING btree (hash_sha512);


--
-- Name: index_fmds_on_name; Type: INDEX; Schema: public; Owner: vagrant
--

CREATE INDEX index_fmds_on_name ON fmds USING btree (name);


--
-- Name: index_fmds_on_original_name; Type: INDEX; Schema: public; Owner: vagrant
--

CREATE INDEX index_fmds_on_original_name ON fmds USING btree (original_name);


--
-- Name: index_fmds_on_partner_id; Type: INDEX; Schema: public; Owner: vagrant
--

CREATE INDEX index_fmds_on_partner_id ON fmds USING btree (partner_id);


--
-- Name: index_fmds_on_status; Type: INDEX; Schema: public; Owner: vagrant
--

CREATE INDEX index_fmds_on_status ON fmds USING btree (status);


--
-- Name: index_fmds_on_xip_id; Type: INDEX; Schema: public; Owner: vagrant
--

CREATE INDEX index_fmds_on_xip_id ON fmds USING btree (xip_id);


--
-- Name: index_ie_to_ses_on_ie_id; Type: INDEX; Schema: public; Owner: vagrant
--

CREATE INDEX index_ie_to_ses_on_ie_id ON ie_to_ses USING btree (ie_id);


--
-- Name: index_ie_to_ses_on_ie_id_and_se_id_and_section; Type: INDEX; Schema: public; Owner: vagrant
--

CREATE UNIQUE INDEX index_ie_to_ses_on_ie_id_and_se_id_and_section ON ie_to_ses USING btree (ie_id, se_id, section);


--
-- Name: index_ie_to_ses_on_se_id; Type: INDEX; Schema: public; Owner: vagrant
--

CREATE INDEX index_ie_to_ses_on_se_id ON ie_to_ses USING btree (se_id);


--
-- Name: index_ies_on_coll_id; Type: INDEX; Schema: public; Owner: vagrant
--

CREATE INDEX index_ies_on_coll_id ON ies USING btree (coll_id);


--
-- Name: index_ies_on_coll_id_and_sys_num; Type: INDEX; Schema: public; Owner: vagrant
--

CREATE UNIQUE INDEX index_ies_on_coll_id_and_sys_num ON ies USING btree (coll_id, sys_num);


--
-- Name: index_ies_on_sys_num; Type: INDEX; Schema: public; Owner: vagrant
--

CREATE INDEX index_ies_on_sys_num ON ies USING btree (sys_num);


--
-- Name: index_partners_on_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_partners_on_code ON partners USING btree (code);


--
-- Name: index_partners_on_rel_path; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_partners_on_rel_path ON partners USING btree (rel_path);


--
-- Name: index_providers_on_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_providers_on_name ON providers USING btree (name);


--
-- Name: index_ses_on_coll_id; Type: INDEX; Schema: public; Owner: vagrant
--

CREATE INDEX index_ses_on_coll_id ON ses USING btree (coll_id);


--
-- Name: index_ses_on_digi_id; Type: INDEX; Schema: public; Owner: vagrant
--

CREATE INDEX index_ses_on_digi_id ON ses USING btree (digi_id);


--
-- Name: unique_schema_migrations; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX unique_schema_migrations ON schema_migrations USING btree (version);


--
-- Name: batch_to_ies_batch_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY batch_to_ies
    ADD CONSTRAINT batch_to_ies_batch_id_fk FOREIGN KEY (batch_id) REFERENCES batches(id);


--
-- Name: batch_to_ies_ie_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY batch_to_ies
    ADD CONSTRAINT batch_to_ies_ie_id_fk FOREIGN KEY (ie_id) REFERENCES ies(id);


--
-- Name: batch_to_ses_batch_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY batch_to_ses
    ADD CONSTRAINT batch_to_ses_batch_id_fk FOREIGN KEY (batch_id) REFERENCES batches(id);


--
-- Name: batch_to_ses_se_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY batch_to_ses
    ADD CONSTRAINT batch_to_ses_se_id_fk FOREIGN KEY (se_id) REFERENCES ses(id);


--
-- Name: batches_coll_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY batches
    ADD CONSTRAINT batches_coll_id_fk FOREIGN KEY (coll_id) REFERENCES colls(id);


--
-- Name: bdis_se_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY bdis
    ADD CONSTRAINT bdis_se_id_fk FOREIGN KEY (se_id) REFERENCES ses(id);


--
-- Name: colls_partner_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY colls
    ADD CONSTRAINT colls_partner_id_fk FOREIGN KEY (partner_id) REFERENCES partners(id);


--
-- Name: etofmds_fmd_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY etofmds
    ADD CONSTRAINT etofmds_fmd_id_fk FOREIGN KEY (fmd_id) REFERENCES fmds(id);


--
-- Name: fmds_coll_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY fmds
    ADD CONSTRAINT fmds_coll_id_fk FOREIGN KEY (coll_id) REFERENCES colls(id);


--
-- Name: fmds_partner_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY fmds
    ADD CONSTRAINT fmds_partner_id_fk FOREIGN KEY (partner_id) REFERENCES partners(id);


--
-- Name: ie_to_ses_ie_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY ie_to_ses
    ADD CONSTRAINT ie_to_ses_ie_id_fk FOREIGN KEY (ie_id) REFERENCES ies(id);


--
-- Name: ie_to_ses_se_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY ie_to_ses
    ADD CONSTRAINT ie_to_ses_se_id_fk FOREIGN KEY (se_id) REFERENCES ses(id);


--
-- Name: ies_coll_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY ies
    ADD CONSTRAINT ies_coll_id_fk FOREIGN KEY (coll_id) REFERENCES colls(id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

